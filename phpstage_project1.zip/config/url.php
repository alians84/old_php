<?php
define('SITEURL', 'http://localhost/phpstage_project');