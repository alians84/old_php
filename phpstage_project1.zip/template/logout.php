<?php
require_once 'config/url.php';
/**
 * logout page template
 */

logout();